package com.intiFormation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormationApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
