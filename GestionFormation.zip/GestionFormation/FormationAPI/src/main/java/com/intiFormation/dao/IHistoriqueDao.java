package com.intiFormation.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.intiFormation.model.Historique;

public interface IHistoriqueDao extends JpaRepository<Historique, Integer>{

}
